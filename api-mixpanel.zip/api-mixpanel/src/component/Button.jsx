import React, {Component} from "react";

class Button extends Component
{
    button_callback =() =>
        {
            console.log("clicked")
        }
    render()
    {
        return (
          <button type="button" class="btn btn-primary">
            Primary
          </button>
        );
    }
}
export default Button