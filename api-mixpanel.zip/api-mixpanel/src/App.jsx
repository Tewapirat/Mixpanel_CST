import './App.css'
import mixpanel from 'mixpanel-browser';
import Button from './component/Button';

// mixpanel=> test-project
//mixpanel.init("641203d11511fc3395df8cd545b85419",{
  //debug : true, track_pageview: true
//})

mixpanel.init("29d1b6b47f53916f7c6d86e933d3f68b", {
  debug: true,
  track_pageview: true,
});


mixpanel.identify('2024')
mixpanel.people.set({
  '$name': 'Jane Doe',
  '$email': 'jane.doe@example.com',
  'plan':'Premium'

})





function App() {
 let btnClick =(e)=>{
  mixpanel.track("Clicked", {
    name: "Tew",
    age: 26,
    sex: "Male",
  })
 }
 


  return (
   <div className='App'>
    <button onClick={btnClick}>Send data</button>
    <Button></Button>
   </div>
  )
}

export default App
